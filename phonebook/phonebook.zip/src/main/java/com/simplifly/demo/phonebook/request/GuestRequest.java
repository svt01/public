package com.simplifly.demo.phonebook.request;

public class GuestRequest {
	private String guestName;

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

}