package com.simplifly.demo.phonebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhonebookApplicationTests {

	@Test
	void contextLoads() {
	}

}
